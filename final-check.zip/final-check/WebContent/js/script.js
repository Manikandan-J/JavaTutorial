function validateForm() {
    var s = document.myForm.title.value;
    var letters = /^[A-Za-z]+$/
    if (s == "") {
        alert("Title is required");
        return false;
    }
    else if (s.length < 2 || s.length > 65) {
        alert("Title should have 2 to 65 characters");
        return false;
    }
    var price = document.myForm.boxOffice.value;
    if (price == "") {
        alert("price is required");
        return false;
    }
    else if (price.match(letters)) {
        alert("price has to be a number.");
        return false;
    }
    var date = document.myForm.dateOfLaunch.value;
    if (date == "") {
        alert("date of launch is required");
        return false;
    }
    var category = document.myForm.genre.value;
    if (category == "") {
        alert("Select one category");
        return false;
    }
}