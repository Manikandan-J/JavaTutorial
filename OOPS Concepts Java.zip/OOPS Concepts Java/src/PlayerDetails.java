import java.util.Scanner;

interface PlayerStatistics
{
	public void displayPlayerStatisitcs();
}
abstract class Player
{
	protected String name;
	protected String teamName;
	protected int noOfMatches;
	public Player(String name, String teamName, int noOfMatches) {
		super();
		this.name = name;
		this.teamName = teamName;
		this.noOfMatches = noOfMatches;
	}
	
}
class CricketPlayer extends Player implements PlayerStatistics
{

	 private int totalRunsScored;
	 private int noOfWicketsTaken;
	 
	public CricketPlayer(String name,String teamName,int noOfMatches,int totalRunsScored,int noOfWicketsTaken)
	{
		super(name, teamName, noOfMatches);
		this.totalRunsScored = totalRunsScored;
		this.noOfWicketsTaken = noOfWicketsTaken;
		
	}
	
	

	@Override
	public void displayPlayerStatisitcs() {
		
		System.out.println("Player Details");
		System.out.println("Player name:"+ name);
		System.out.println("Team name:"+ teamName);
		System.out.println("No of matches:"+noOfMatches);
		System.out.println("Total runsscored:"+totalRunsScored);
		System.out.println("No of wickets taken :"+noOfWicketsTaken);
		
	}
	
}
class HockeyPlayer extends Player implements PlayerStatistics
{
	 private String position;
	 private int noOfGoals;

	public HockeyPlayer(String name,String teamName,int noOfMatches,String position,int noOfGoals)
	{
		super(name, teamName, noOfMatches);
		this.position = position;
		this.noOfGoals = noOfGoals;
		
		
		
	}

	@Override
	public void displayPlayerStatisitcs() {
		System.out.println("Player Details");
		System.out.println("Player name:"+ name);
		System.out.println("Team name:"+ teamName);
		System.out.println("No of matches:"+noOfMatches);
		System.out.println("Position:"+position);
		System.out.println("No of goals taken :"+noOfGoals);
		
	}
	
}
public class PlayerDetails {

	public static void main(String[] args) {
		
		int choice;
		String name,teamName,position;
		int noOfMatches,totalRunsScored,noOfWicketsTaken,noOfGoals;
		PlayerStatistics obj = null;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Menu\n1.Cricket Player Details\n2.Hockey Player Details");
		System.out.println("Enter Choice");
		choice = Integer.parseInt(sc.nextLine());
		System.out.println("Enter the Player Name");
		name = sc.nextLine();
		System.out.println("Enter team name");
		teamName = sc.nextLine();
		System.out.println("Enter the number of matches played");
		noOfMatches = Integer.parseInt(sc.nextLine());
		if(choice == 1)
		{
			System.out.println("Enter the total runs Scored");
			totalRunsScored = Integer.parseInt(sc.nextLine());
			System.out.println("Enter the total number of wickets taken");
			noOfWicketsTaken = Integer.parseInt(sc.nextLine());
			obj = new CricketPlayer(name, teamName, noOfMatches, totalRunsScored, noOfWicketsTaken);
		}
		if(choice ==2)
		{
			System.out.println("Enter the position");
			position = sc.nextLine();
			System.out.println("Enter total number of goals taken");
			noOfGoals = Integer.parseInt(sc.nextLine());
			obj = new HockeyPlayer(name, teamName, noOfMatches, position, noOfGoals);
			
		}
		obj.displayPlayerStatisitcs();
		
	}

}
