
public class Exception3 {
	
	static void demoProc()
	{
		try {
			
			throw new NullPointerException();
			
		} catch (NullPointerException e) {
			
			System.out.println("caught "+e);
			throw e;
			// TODO: handle exception
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	  try {
		  
		  demoProc();
		
	} catch (NullPointerException e)
	  {
		// TODO: handle exception
		System.out.println("Re caught " +e);
	}

	}

}
