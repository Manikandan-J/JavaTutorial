
public class Main8 {

	   static int a = 4;
	   static int b;
	   static void meth(int x)
	   {
		   System.out.println(x+" "+a+" "+b);
	   }
	   static
	   {
		   System.out.println("BLock initialized");
		   b = a*3;
	   }
	public static void main(String[] args) {
		
		meth(20);

	}

}
