import java.util.ArrayList;
import java.util.Scanner;

class Player21
{
	private String name;
	private String country;
	private String skill;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public Player21(String name, String country, String skill) {
		super();
		this.name = name;
		this.country = country;
		this.skill = skill;
	}
	@Override
	public String toString() {
		return String.format("%-15s%-15s%-15s",name,country,skill);
	}
	
}
class PlayerBO
{
	 void displayAllPlayerDetails(ArrayList<Player21> playerList)
	{
		for(Player21 p:playerList)
		{
			System.out.println(p);
		}
	}
}
public class PlayerDetailsArrayList {

	public static void main(String[] args) {
		
		ArrayList<Player21> playerDetails = new ArrayList<>();
		int n;
		String name,country,skill;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of players");
		n = Integer.parseInt(sc.nextLine());
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the player name");
			name = sc.nextLine();
			System.out.println("Enter the country name");
			country = sc.nextLine();
			System.out.println("Enter the skill");
			skill = sc.nextLine();
			Player21 p = new Player21(name, country, skill);
			playerDetails.add(p);
		}
		PlayerBO obj = new PlayerBO();
		obj.displayAllPlayerDetails(playerDetails);
		

	}

}
