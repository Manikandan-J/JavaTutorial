import java.util.LinkedList;
import java.util.List;

public class CollectionLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> ll = new LinkedList<>(); 
		System.out.println("Size"+ ll.size());
		ll.add(10);
		ll.add(2);
		ll.add(5);
		ll.addFirst(5);
		ll.addLast(6);
		ll.add(2,8);
		System.out.println(ll);
		ll.remove(2);
		ll.removeFirst();
		ll.removeLast();
		System.out.println("After remove method"+ ll);
		System.out.println(ll.get(1));
		System.out.println(ll.getFirst());
		System.out.println(ll.getLast());
		

	}

}
