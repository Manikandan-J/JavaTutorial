
class A9 implements Maths
{

	@Override
	public void arithmatic(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
		System.out.println(Maths.c);
		
	}
	
}
class B9 implements Maths
{

	@Override
	public void arithmatic(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a-b);
		
		
	}
	void show()
	{
		System.out.println("Non implemented method");
	}
}
public class InterfaceMain
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Maths m = new A9();
      m.arithmatic(10, 20);
      m = new B9();
      m.arithmatic(30, 40);
      ((B9) m).show();
	}

}
