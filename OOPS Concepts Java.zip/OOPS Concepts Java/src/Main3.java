
class Box3{

	   double width;
	   double height;
	   double depth;
	 
	   public Box3() {
		System.out.println("Initiallizing box");
		width = 10;
		height = 20;
		depth = 15;
	
	}

	public Box3(double width, double height, double depth) {
		
		this.width = width;
		this.height = height;
		this.depth =depth;
	}

	double  volume()
	   {
		   
		   return width*height*depth;
	   }
}
public class Main3 {

	public static void main(String[] args) {
		Box3 b = new Box3();
		Box3 b1 = new Box3(3,6,9);
       double vol;
    
       vol = b.volume();
		 System.out.println("volume is "+vol);
		 vol = b1.volume();
		 System.out.println("volume is "+vol);
	}

}
