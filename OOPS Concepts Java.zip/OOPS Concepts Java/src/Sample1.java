class MessageDetails {  
    public static void main(String[] args) {        
        String message = null;      
        if (message.equals("message1")) {          
            System.out.print("Same");      
        }else {          
            System.out.print("Not Same");        
        }
    }
}