
public class StringBufferMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer s = new StringBuffer();
		System.out.println(s.capacity());
		StringBuffer sb = new StringBuffer("hello");
		System.out.println(sb.length());
		System.out.println(sb.charAt(1));
		sb.setCharAt(1, 'i');
		System.out.println(sb);
		sb.setLength(2);
		System.out.println(sb);
		System.out.println(sb.capacity());
		String sa;
		int a =42;
        StringBuffer sbo  = new StringBuffer(40);
        sa = sbo.append("a = ").append(a).append("!").toString();
        System.out.println(sa);
        StringBuffer sd = new StringBuffer("I  java ! ");
        sd.insert(2,"Like");
        System.out.println(sd);
        System.out.println(sd.reverse());
        
       
       System.out.println(sd.delete(3, 5));
        
	}

}
