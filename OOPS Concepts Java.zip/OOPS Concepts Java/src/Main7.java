class Varargs
{
	void test(int... a)
	{
		for(int a1:a)
			System.out.println(a1);
	}
	void test(boolean...b)
	{
		for (boolean b1:b)
			System.out.println(b1);
	}
	void test(int a,String...s)
	{
		
		System.out.println(a);
		for(String s1:s)
		{
			System.out.println(s1);
		}
		
	}
}

public class Main7 {

	public static void main(String[] args) {
		Varargs v = new Varargs();
		v.test(1,2,3,4,5,6,7,8);
		v.test(10,"a","b","c");
		v.test(true,false,false);
		v.test(20,45);
		v.test(false);

	}

}
