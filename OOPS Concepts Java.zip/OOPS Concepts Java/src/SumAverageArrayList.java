import java.util.ArrayList;
import java.util.Scanner;

public class SumAverageArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,c,sum=0;
		float average;
		ArrayList<Integer> a = new ArrayList<>();
		Scanner sc= new Scanner(System.in);
		n = Integer.parseInt(sc.next());
		for(int i=0;i<n;i++)
		{
			c = Integer.parseInt(sc.next());
			a.add(c);
		}
		for(int b:a)
		{
			sum+=b;
		}
		average = (float)sum/n;
		System.out.printf("%d\n%.2f",sum,average);

	}

}
