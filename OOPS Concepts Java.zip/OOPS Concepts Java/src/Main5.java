class Overload
{
	void test()
	{
		System.out.println("no parameter");
	}
	void test(int a)
	{
		System.out.println("a = "+a);
	}
	void test(int a,int b)
	{
		System.out.println("a = "+a+" "+"b = "+b);
	
	}
	double test(double a)
	{
		System.out.println("a = "+a);
		return a*a;
	}
}
public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Overload o = new Overload();
       o.test();
       o.test(10);
       o.test(10,20);
       double result = o.test(123.4);
       System.out.println(result);
	}

}
