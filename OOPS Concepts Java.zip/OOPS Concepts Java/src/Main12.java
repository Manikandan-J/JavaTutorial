class Box5
{
	   double width;
	   double height;
	   double depth;
	   double volume()
	   {
		   return (width*height*depth);
	   }
}
class BoxWeight extends Box5
{
	double weight;
	 BoxWeight(double w,double d,double h,double m) {
		 width = w;
		 depth = d;
		  height = h;
		  weight = m;
		
	}
}
public class Main12 {

	public static void main(String[] args) {
	
		BoxWeight b = new BoxWeight(10,20,15,3);
		double vol;
		vol = b.volume();
		System.out.println("Volume is "+ vol);
		System.out.println("Weight is "+b.weight);
	}

}