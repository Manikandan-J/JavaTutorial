import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Collection1 {

	public static void main(String[] args) {
		
		List<Employee> l = new ArrayList<Employee>(); //jdk1.7
		List<String> l1 = new ArrayList<>();
		ArrayList<String> al1 = new ArrayList<>();
		
		System.out.println(l1.size());
		l1.add("b");
		l1.add("c");
		l1.add("a");
		l1.add(1,"e");
		l1.add("1");
		l1.add("a");
		System.out.println(l1.size());
		System.out.println(l1);
		
		for (int i = 0; i <l1.size(); i++) {
			
			System.out.println(l1.get(i));
			
		}
		for(String s1:l1)
		{
			System.out.println(s1);
		}
		//Iterator interface used to access individual e;ts of collection
		//boolean hasNext() --> checks whether it contains more elts.
		//Object next() --> returns single elt
		//void remove()
		
		Iterator itr = l1.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		//ListIterator interface used to access individuals elts of collection both forward and backward
		//boolean hasNext() --> checks whether it contains more elts.
				//Object next() --> returns single element
				//void remove()
		 
		//boolean hasPrecious().
		//Object previous();
		//void add( Object obj)
		//Object set(int index,Object obj)
		ArrayList<String> al = new ArrayList<>();
		al.add("c");
		al.add("A");
		al.add("c");
		al.add("E");
		
		al.add("B");
		ListIterator litr = al.listIterator();
		while (litr.hasNext()) {
			Object element =  litr.next();
			System.out.println(element + "+ ");
			
			
		}
		
		System.out.println("Printing in backward");
		
		while (litr.hasPrevious()) {
			Object elt =  litr.previous();
			System.out.println(elt + " ");
			
		}
		al.remove(2);
		al.remove("F+");
		System.out.println(al);
		al1.addAll(al);
		System.out.println(al1+ "AddAll");
		al1.removeAll(al);
		System.out.println(al1);

	}

}
