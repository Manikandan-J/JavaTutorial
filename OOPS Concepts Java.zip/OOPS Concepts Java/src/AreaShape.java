import java.util.Scanner;

class Shape {
	protected String shapeName;

	double calculateArea() {
		return 0;

	}

	public Shape(String shapeName) {
		super();
		this.shapeName = shapeName;
	}

}

class Square extends Shape {
	int side;

	double calculateArea() {

		return side * side;

	}

	public Square(int side) {
		super("Square");
		this.side = side;
	}

}

class Rectangle extends Shape {

	int length;
	int breadth;

	double calculateArea() {

		return length * breadth;

	}

	public Rectangle(int length, int breadth) {
		super("Rectangle");
		this.length = length;
		this.breadth = breadth;
	}

}
class Hexagon extends Shape
{
     int side;

	public Hexagon(String shapeName, int side) {
		super(shapeName);
		this.side = side;
	}

	
	
}

class Circle extends Shape {
	int radius;

	double calculateArea() {
		return 3.14159 * radius * radius;
	}

	public Circle(int radius) {
		super("Circle");
		this.radius = radius;
	}

}

public class AreaShape {

	public static void main(String[] args) {
		int option;

		Scanner sc = new Scanner(System.in);
		System.out.printf("1.Rectangle\n\n2.Square\n\n3.Circle\n\n4.Hexagon\n\nChoose your shape");
		option = Integer.parseInt(sc.next());
		if (option == 1) {
			System.out.println("Enter the length and breadth");
			Rectangle rec = new Rectangle(Integer.parseInt(sc.next()), Integer.parseInt(sc.next()));
			System.out.printf("Area of Rectangle is: %.2f",rec.calculateArea());

		}
		if (option == 2) {
			System.out.println("Enter side:");
			Square sqr = new Square(Integer.parseInt(sc.next()));
			System.out.printf("Area of Square is: %.2f", sqr.calculateArea());

		}
		if (option == 3) {
			System.out.println("Enter Radius:");
			Circle cir = new Circle(Integer.parseInt(sc.next()));
			System.out.printf("Area of Circle is: %.2f",cir.calculateArea());

		}
		
		if (option == 4) {
			System.out.println("Enter side:");
			
			Hexagon hex = new Hexagon("Hexagon",Integer.parseInt(sc.next()));
			System.out.printf("Area of Circle is: %.2f",hex.calculateArea());

		}
		
	}

}
