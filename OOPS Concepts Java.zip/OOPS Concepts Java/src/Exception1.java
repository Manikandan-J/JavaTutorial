
public class Exception1 {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		try
		{
		int d,a = 10;
		d  = a/0;
		System.out.println(d);

	}
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("Divide by 0");
			System.out.println(e);
		}

}
}
