import java.util.Scanner;

class Product
{
	private long id;
	private String productName;
	private String supplierName;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getSupplierName() {
		return supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
}
public class EBox {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Product p = new Product();
		System.out.println("Enter the product id");
		p.setId(sc.nextLong());
		System.out.println("Enter the product name");
		p.setProductName(sc.nextLine());
		System.out.println("Enter the supplier name");
		p.setSupplierName( sc.nextLine());
		
		System.out.println("Product Id is"+ p.getId());
		System.out.println("Product Name is"+p.getProductName());
		System.out.println("Supplier Name is"+p.getSupplierName());
	}

}
