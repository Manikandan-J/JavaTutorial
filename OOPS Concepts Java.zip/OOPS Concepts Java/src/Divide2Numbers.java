import java.util.Scanner;

public class Divide2Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the 2 numbers");
		a = Integer.parseInt(sc.nextLine());
		b = Integer.parseInt(sc.nextLine());
		
		try
		{
			System.out.println("The quotient of "+a+"/"+b+"="+a/b);
		}
		catch(Exception e)
		{
			System.out.println("DivideByZeroException caught");
		}
		finally {
			try
			{
			System.out.println("Inside finally block");
			}
			finally
			{
			  sc.close();	
			}
		}
	
		

	}

}
