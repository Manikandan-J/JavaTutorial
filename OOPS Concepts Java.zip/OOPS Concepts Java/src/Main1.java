
class Box1{

	   double width;
	   double height;
	   double depth;
	   double  volume()
	   {
		   
		   return width*height*depth;
	   }
}
public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box1 b = new Box1();
		b.width = 10;
		b.height = 20;
		b.depth = 15;
		System.out.println("Volume is " + b.volume());

	}

}
