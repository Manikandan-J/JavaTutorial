package Annotations;



public class AnnotaionTarget {
	@Example(add = "hello")
	void show()
	{
		System.out.println("Show method");
	}

	public static void main(String[] args) {
		
		AnnotaionTarget obj = new AnnotaionTarget();
		obj.show();

	}

}
