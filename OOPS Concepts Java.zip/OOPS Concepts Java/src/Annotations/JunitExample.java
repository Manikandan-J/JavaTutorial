package Annotations;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JunitExample {

	@Test
	void test() {
		
		String str1 = new String("Hello");
		String str2 = new String("Hello");
		String str3 = null;
		String str4 = "Hello";
		String str5 = "Hello";
		int a =5,b=6;
		assertEquals(str1, str2);
		assertTrue(a<b);
		assertFalse(a>b);
		assertNotNull(str1);
		assertNull(str3);
		assertSame(str4,str5);
	}

}
