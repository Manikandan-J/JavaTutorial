class A
{
	A()
	{
		this(10);
		
		System.out.println("default Constructor");
	}
	A(int a)
	{
	  
	
		System.out.println("int Constructor");
	}
	A(String s)
	{
		this();
		System.out.println("String  constructor");
	}
}
public class Main4 {

	public static void main(String[] args) {
		
		//A a1 = new A();
		//A a2 = new  A(10);
		A a3 = new A("hello");

	}

}
