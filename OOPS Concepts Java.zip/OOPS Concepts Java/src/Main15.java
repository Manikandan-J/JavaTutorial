class A4
{
	
	A4(int a)
	{
		System.out.println("A4 Constructor");
	}
}
class B4 extends A4
{
	
	B4()
	{
	super(10);
		System.out.println("B4 Constructor");
	}
}
class C4 extends B4
{
	C4()
	{
		System.out.println("C4 Constructor");
	}
}
public class Main15 {

	public static void main(String[] args) {
	
		C4 c = new C4();
		

	}

}
