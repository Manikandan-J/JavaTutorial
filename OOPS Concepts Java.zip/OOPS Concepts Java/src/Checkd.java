import java.util.HashMap;
  public  class Checkd {  
        public static void main(String args[]) {        
            HashMap cards= new HashMap();        
            cards.put("A", new Integer(1));        
            cards.put("B", new Integer(2));        
            cards.put("C", new Integer(3));        
            System.out.println(cards.get("B"));  
    }
}