class A1
{
	static int a = 20;
	static int b = 30;
	static void meth()

    { 
		System.out.println(a);
		
    }
}
public class Main9 {

	public static void main(String[] args) {
    
		A1.meth();
		System.out.println(A1.b);

	}

}
