import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class HashMapKeyValuePlayersEBox {

	public static void main(String[] args) {
		
		HashMap<String,Long> hm = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		int n;
		String name;
		Long runs;
		System.out.println("Enter the number of players");
		n = Integer.parseInt(sc.nextLine());
        for(int i = 0;i<n;i++)
        {
        	System.out.println("Enter the details pf the player "+i+1);
        	name = sc.nextLine();
        	runs = Long.parseLong(sc.nextLine());
        	hm.put(name, runs);
        }
        ArrayList<Long> al = new ArrayList<>();
        for (Long m : hm.values()) {
        	
            al.add(m);
        }
        Long max = (long) 0;
        for (int i=0; i<al.size();i++) {
            if (al.get(i)> max) {
                max = al.get(i);
            }
        }
       
         System.out.println(getKeyFromValue(hm,max));
	}

	  public static String getKeyFromValue(HashMap hm,Long value) {
		    for (Object o : hm.keySet()) {
		      if (hm.get(o).equals(value)) {
		        return (String) o;
		      }
		    }
		    return null;
		  }
}
