
public interface Maths {
	
	void arithmatic(int a,int b);
	int c = 20;
}
