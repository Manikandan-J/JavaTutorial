import java.util.*;

class Mainh {

	public static void main(String args[]) {

		int x, y, z;

		Scanner sc = new Scanner(System.in);
		Mainh obj = new Mainh();

		System.out.println("Enter the number of dozens of toys purchased");
		x = sc.nextInt();
		System.out.println("Enter the price per dozen");
		y = sc.nextInt();
		System.out.println("Enter the selling price of 1 toy");
		z = sc.nextInt();

		sc.close();

		System.out.printf("Sam's profit percentage is %.2f percent", obj.calculateProfit(x, y, z));

	}

	public float calculateProfit(int dozenCount, int pricePerDozen, int sellPrice) {

		float costPrice = (float) pricePerDozen / 12;
		float sellingPrice = sellPrice;
		float profit = sellingPrice - costPrice;
		float ans = profit / costPrice * 100;

		return ans;

	}

}