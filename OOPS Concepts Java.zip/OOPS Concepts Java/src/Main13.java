class Box6{
	   private  double width;
	   private double height;
	   private double depth;
	   double volume()
	   {
		   return (width*height*depth);
	   }
	   Box6()
	   {
		   width = -1;
		   height = -1;
		   depth = -1;
		   
	   }
	   Box6(Box6 ob)
	   {
		   width = ob.width;
		   height = ob.height;
		   depth = ob.depth;
		   
	   }
	   Box6(double len)
	   {
		   width=height=depth=len;
	   }
	   Box6(double w,double h,double d)
	   {
		   width = w;
		   height =h;
		   depth = d;
	   }
}
class Boxweight1 extends Box6
{
	double weight;
	Boxweight1(){
		super();
		weight =-1;
	}
Boxweight1(Boxweight1 ob)
{
	super(ob);
	weight = ob.weight;
}
Boxweight1(double l,double we)
{
	super(l);
	weight = we;
}
Boxweight1(double w,double h,double d,double m)
{
	super(w,h,d);
	weight = m;
}


}
class Shipment extends Boxweight1
{
	double cost;
	Shipment(double w,double h,double d,double m,double c)
	{
		super(w,h,d,m);
		cost = c;
	}
	
}
public class Main13 {

	public static void main(String[] args) {
		
     
	/*	Boxweight1 b1 = new Boxweight1();
		Boxweight1 b2 = new Boxweight1(1,2,3,4);
		Boxweight1 b3 = new Boxweight1(3,2);
		Boxweight1 b4 = new Boxweight1(b1);
		double vol;
		vol = b1.volume();
		System.out.println(vol+" "+b1.weight);
		vol = b2.volume();
		System.out.println(vol+" "+b2.weight);
		vol = b3.volume();
		System.out.println(vol+" "+b3.weight);
		vol = b4.volume();
		System.out.println(vol+" "+b4.weight);*/
		Shipment s = new Shipment(1,2,3,4,5);
		double vol = s.volume();
		System.out.println(vol);
		System.out.println(s.weight);
		System.out.println(s.cost);
		
		
		
	}

}
