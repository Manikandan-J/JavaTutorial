import java.awt.DisplayMode;
import java.util.Scanner;

class Product2 {
	private Long id;
	private String productName;
	private String supplierName;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public Product2() {

	}

	public Product2(Long id, String productName, String supplierName) {
		super();
		this.id = id;
		this.productName = productName;
		this.supplierName = supplierName;
	}

	@Override
	public String toString() {
		return "Product2 [id=" + id + ", productName=" + productName + ", supplierName=" + supplierName + "]";
	}



}

public class DisplayProductDetails {

	static long id;
	static String productName;
	static String supplierName;

	static void display() {
		System.out.println("Product Id is " + id);
		System.out.println("Product Name is" + productName);
		System.out.println("Supplier Name is" + supplierName);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean res;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the product id");
		id = Long.parseLong(sc.nextLine());
		System.out.println("Enter the product name");
		productName = sc.nextLine();
		System.out.println("Enter the supplier name");
		supplierName = sc.nextLine();
		display();
		Product2 obj1 = new Product2(id, productName, supplierName);
		System.out.println(obj1);
		System.out.println("Invoking get class method"+obj1.getClass());
		

	}

}
