interface A10
{
	void add1();
}
interface B10
{
	void add2();
}
interface C10 extends A10,B10
{
	void add3();
}
class D10 implements C10
{

	@Override
	public void add1() {
		// TODO Auto-generated method stub
		System.out.println("add1");
	}

	@Override
	public void add2() {
		// TODO Auto-generated method stub
		System.out.println("add2");
	}

	@Override
	public void add3() {
		// TODO Auto-generated method stub
		System.out.println("add3");
	}
	
}
public class MainInterfaceEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      D10 d = new D10();
      d.add1();
      d.add2();
      d.add3();
	}

}
