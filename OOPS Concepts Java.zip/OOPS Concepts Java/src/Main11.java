class A2{
	int i,j;
	void showij() {
		System.out.println(i+" "+j);
	}
}
class B2 extends A2
{
	int k;
	void show()
	{
		System.out.println(k);
	}
	void sum()
	{
		System.out.println(i+j+k);
	}
}
public class Main11 {

	public static void main(String[] args) {
		
       
		A2 a = new A2();
		a.i =1;
		a.j = 2;
		a.showij();
		B2 b = new B2();
		b.i = 3;
		b.j = 4;
		b.k = 5;
		b.showij();
		b.show();
		b.sum();
		
	}

}
