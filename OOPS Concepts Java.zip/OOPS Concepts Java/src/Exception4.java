import javax.management.RuntimeErrorException;

public class Exception4 {

	static void procA()
	{
		try {
			
			System.out.println("Inside procA");
			throw new RuntimeException();
			
		}
		finally {
			
			System.out.println("procA finally");
			
		}
	}
	static void procB() {
		
		try {
			System.out.println("Inside ProcB");
			return;
		} finally {
			// syso: handle finally clause
		System.out.println("ProcB Finally");
		}
		
	}
	
static void procC() {
		
		try {
			System.out.println("Inside ProcC");
			return;
		} finally {
			// syso: handle finally clause
		System.out.println("ProcC Finally");
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			procA();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Caught exception");
		}
		procB();
		procC();

	}
      

}
