class A7//Hierarchial inheritance
{
	void call()
	{
		System.out.println("A7 method");
	}
}
class B7 extends A7
{
	void call()
	{
		System.out.println("B7 method");
	}
}
class C7 extends A7
{
	void call()
	{
		System.out.println("C7 Method");
	}
}
public class Main18 {

	public static void main(String[] args) {
		
		A7 a= new A7();
		a.call();
		a = new B7();
		a.call();
		

	}

}
