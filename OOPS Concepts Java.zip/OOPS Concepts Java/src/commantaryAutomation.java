import java.util.Scanner;

class Delivery
{
	void displayDeliveryDetails(String bowler,String batsman)
	{
		String[] name = bowler.split(" ");
		System.out.println("Bowler:"+name[1]);
		name = batsman.split(" ");
		System.out.println("Batsman:"+name[1]);
		
	}
	void displayDeliveryDetails(Long runs)
	{
		
	}
}
public class commantaryAutomation {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int option;
		Delivery obj = new Delivery();
		System.out.println("Menu\n\n1.Player details of the delivery\n\n2.Run details of the delivery");
		option = Integer.parseInt(sc.nextLine());
		if(option == 1)
		{
			String bowlerName;
			System.out.println("Enter the bowler name");
			bowlerName = sc.nextLine();
			String batsmanName;
			System.out.println("Enter the batsman name");
			batsmanName = sc.nextLine();
			obj.displayDeliveryDetails(bowlerName, batsmanName);
			
		}
		if(option == 2)
		{
			
		}

	}

}
