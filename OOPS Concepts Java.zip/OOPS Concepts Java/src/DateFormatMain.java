import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class DateFormatMain {

	public static void main(String[] args) 
	{
      Date d = new Date();
      System.out.println(d);
      Scanner s = new Scanner(System.in);
      System.out.println("Enter Date of birth(ddMM/yy)");
      String dat = s.nextLine();
      SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyyy");
      sd.setLenient(false);
      Date d1 = null;
      try
      {
    	 d1 = sd.parse(dat);
    	  System.out.println(d1);
      }
      catch (ParseException e) {
		
    	  System.out.println(e);
	}
     // SimpleDateFormat sd1 = new SimpleDateFormat("dd-MM-yyyy");
      String s2 = sd.format(d1);
      System.out.println(s2);

	}

}
