import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter f = new FileWriter("C:\\java\\b.txt",true);
		f.write(" Now It's not Ovverride just Append");
		f.close();

	}

}
