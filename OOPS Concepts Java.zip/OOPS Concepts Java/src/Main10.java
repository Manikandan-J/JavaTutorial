import static java.lang.Math.*;
import static java.lang.System.*;

public class Main10 {

	public static void main(String[] args) {
	
		
		double d =sqrt(16);
		out.println(d);

	}

}
