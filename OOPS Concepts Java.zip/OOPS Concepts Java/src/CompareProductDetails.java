import java.awt.DisplayMode;
import java.util.Scanner;

class Product1 {
	private Long id;
	private String productName;
	private String supplierName;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSupplierName() {
		return supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public Product1() {

	}

	public Product1(Long id, String productName, String supplierName) {
		super();
		this.id = id;
		this.productName = productName;
		this.supplierName = supplierName;
	}

	@Override
	public boolean equals(Object obj) {

		if (obj == this) {
		System.out.println("mani");
			return true;
		}
		if (!(obj instanceof Product1))
			return false;
		Product1 p2 = (Product1) obj;
		if (p2.id.equals(this.id) && p2.productName.equals(this.productName) && p2.supplierName.equals(this.supplierName))
			return true;
		else
			return false;

	}

}

public class CompareProductDetails {

	static long id;
	static String productName;
	static String supplierName;

	static void display() {
		System.out.println("Product Id is " + id);
		System.out.println("Product Name is" + productName);
		System.out.println("Supplier Name is" + supplierName);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean res;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the product id");
		id = Long.parseLong(sc.nextLine());
		System.out.println("Enter the product name");
		productName = sc.nextLine();
		System.out.println("Enter the supplier name");
		supplierName = sc.nextLine();
		display();
		Product1 obj1 = new Product1(id, productName, supplierName);
		System.out.println("Enter the product id");
		id = Long.parseLong(sc.nextLine());
		System.out.println("Enter the product name");
		productName = sc.nextLine();
		System.out.println("Enter the supplier name");
		supplierName = sc.nextLine();
		display();
		Product1 obj2 = new Product1(id, productName, supplierName);

		res = obj1.equals(obj1);

		if (res == true) {
			System.out.println("The two products are the same");
		} else {
			System.out.println("The two products are different");
		}

	}

}
