import java.util.Scanner;

class Amount
{
	private String accountNumber;
	private int balance;
	Amount(String accountNumber,int accountBalance)
	{
		setAccountNumber(accountNumber);
		this.balance = accountBalance;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getBalance() {
		return balance;
	}
	public void deposit(int transactionAmount)
	{
		  int amount;
		  amount = balance+transactionAmount;
		  System.out.println("Your balance after the transaction is: "+amount);
	}
	public void withdraw(int transactionAmount)
	{
		int amount;
		amount =balance-transactionAmount;
		if(balance<transactionAmount)
		{
			System.out.println("Insufficient Balance");
			System.out.println("Your balance after the transaction is: "+ balance );
		}
		else
		{
			System.out.println("Your balance after the transaction is: "+ amount);
		}
		
	}
}
public class AccountTransaction {

	public static void main(String[] args) {
		
		int option,accountBalance;
		String accountNumber;
		int transAmount;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Account Number");
    	accountNumber = sc.next();
    	System.out.println("Enter the Account Balance");
    	accountBalance = Integer.parseInt(sc.next());
    	Amount a = new Amount(accountNumber,accountBalance);
		System.out.println("Enter 1 to deposit an amount,2 to withdraw an amount");
		
	    option = Integer.parseInt(sc.next());
	    if(option==1)
	    {
	    	System.out.println("Enter the amount to deposit");
	    	transAmount = Integer.parseInt(sc.next());
	    	a.deposit(transAmount);
	    	
	    }
	    else if(option==2)
	    {
	    	System.out.println("Enter the amount to withdraw");
	    	transAmount = Integer.parseInt(sc.next());
	    	a.withdraw(transAmount);
	    }
		

	}

}
