class Employee
{
	private String name;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + "]";
	}
}
public class AccesorsMain {

	public static void main(String[] args) {
		
		
           Employee e = new Employee();
           e.setName("Kamal Hassan");
           e.setAge(64);
           //System.out.println(e.getName());
           //System.out.println(e.getAge());
	       System.out.println(e);
	       String s= new String("Hello");
	       System.out.println(s.hashCode());
	       String s1= new String("Hello");
	       System.out.println(s.hashCode());
	}

}
