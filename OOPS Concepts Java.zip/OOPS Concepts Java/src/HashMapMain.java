import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class HashMapMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hashtable<String,Double> hm = new Hashtable<>();
		System.out.println(hm.size());
		hm.put("Tom",-153.2);
		hm.put("Jhon",153.2);
		hm.put("Jim",53.2);
		hm.put("Jack",-563.2);
		hm.put("America",-563.2);
		hm.put("Zebra",-563.2);
		hm.put("jfdk",-563.2);
		System.out.println(hm.size());
		System.out.println(hm);
		Set s = hm.entrySet();
		Iterator i = s.iterator();
		while(i.hasNext())
		{
			Map.Entry me = (Map.Entry) i.next();
			System.out.println(me.getKey()+" "+me.getValue());
		}
		s = hm.keySet();
		i = s.iterator();
		while(i.hasNext())
		{
			String s1 = (String) i.next();
			System.out.println(s1+" "+hm.get(s1));
		}
		Enumeration e = hm.keys();
		while(e.hasMoreElements())
		{
			String s2 = (String) e.nextElement();
			System.out.println(s2+" "+hm.get(s2));
		}
		
		

	}

}
