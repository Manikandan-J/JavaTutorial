import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class SortTheScores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> s = new TreeSet<>();
		int a,n;
		Scanner sc = new Scanner(System.in);
		n = Integer.parseInt(sc.next());
		for(int i=0;i<n;i++)
		{
			a = Integer.parseInt(sc.next());
			s.add(a);
		}
		for(int g:s)
		{
			System.out.println(g);
		}
		

	}

}
