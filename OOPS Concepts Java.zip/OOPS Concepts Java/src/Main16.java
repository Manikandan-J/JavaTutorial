class A5
{
	System.out.println("1");
	static
	{
		System.out.println("2");
	}
	{
		System.out.println("3");
	}
	A5()
	{
		System.out.println("4");
	}
	static 
	{
		System.out.println("5");
	}
	A5(String s)
	{
		this();
		System.out.println("6");
	}
}
class B51 extends A5
{
	static
	{
		System.out.println("7");
	}
	static
	{
		System.out.println("8");
	}
	{
		System.out.println("9");
	}
	
	B51()
	{
	this(10);
		System.out.println("4");
	}
	B51(int a)
	{
	this(10);
		System.out.println("4");
	}
static 
	{
		System.out.println("5");
	}
	B51(String s)
	{
		this();
		System.out.println("6");
	}
}
class C5 extends B51
{
	{
		System.out.println("12");
	}
	static 
	{
		System.out.println("13");
	}
	static
	{
		
	}
}
public class Main16 {

	public static void main(String[] args) {
		

	}

}
