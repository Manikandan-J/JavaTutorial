
class Box2{

	   double width;
	   double height;
	   double depth;
	   void setDim(double w,double h,double d)
	   {
		   width = w;
		   height = h;
		   depth = d;
	   }
	   double  volume()
	   {
		   
		   return width*height*depth;
	   }
}
public class Main2 {

	public static void main(String[] args) {
	
		 Box2 b = new Box2();
		 double vol;
		 b.setDim(10, 20, 15);
		 vol = b.volume();
		 System.out.println("volume is "+vol);
	}

}
