
class Box{

	   double width;
	   double height;
	   double depth;
}
public class Main {

	public static void main(String[] args) {
		
		
		Box b = new Box();
		Box b1 = new Box();
		b.width = 10;
		b.height = 20;
		b.depth = 15;
		b1.width = 1;
		b1.height = 2;
		b1.depth = 1;
		double vol;
		vol = b.width*b.height*b.depth;
		System.out.println("Volume is "+vol);
		vol = b1.width*b1.height*b1.depth;
		System.out.println("Volume is "+vol);
		
	}

}
