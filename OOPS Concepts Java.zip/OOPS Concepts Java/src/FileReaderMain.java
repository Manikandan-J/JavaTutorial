import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderMain {

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		FileReader f = new FileReader("C:\\java\\b.txt");
		int i;
		while((i=f.read())!=-1)
			System.out.println((char)i);
		f.close();
		
		

	}

}
