abstract class A8
{
	//abstract void show();
	void show1()
	{
		System.out.println("Normal Method");
	}
	
}
class B8 extends A8
{
	void show()
	{
		System.out.println("Abstract Method");
	}
}
public class AbstractMainExample {

	public static void main(String[] args) {
		
    B8 b = new B8();
    b.show();
    b.show1();
	}

}
