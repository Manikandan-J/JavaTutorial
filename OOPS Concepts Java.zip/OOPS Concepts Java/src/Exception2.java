public class Exception2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		try
		{
		int b = 42/1;
		int c[] = {1};
		c[33] = 42;
		}
		
		/*catch (ArithmeticException e)
		{
			System.out.println(e);
		}

	
	catch (ArrayIndexOutOfBoundsException e1)
	{
		System.out.println(e1);
	}*/
		catch (ArithmeticException | ArrayIndexOutOfBoundsException|NullPointerException e) {
			
			System.out.println(e);
			// TODO: handle exception
		}

}
}
