




function toggle()
{
    var table = document.getElementById("tab"); 
    var editMenu = document.getElementById("editForm");
 
    table.style.display = (
        table.style.display == "none" ? "block" : "none"); 
        editMenu.style.display = (
        editMenu.style.display == "none" ? "block" : "none")
}


function editItem(item)
{
    //var edittab = document.getElementById('editItemMenu');
    document.querySelector('#itemName').value=item.name;
    document.querySelector('#itemPrice').value=item.price;
    document.querySelector('#itemActive').value=item.Active;
    document.querySelector('#itemDateOfLunch').value=item.date_of_lunch;
    document.querySelector('#itemCategory').value=item.category;
    document.querySelector('#itemFreeDelivery').value=item.date_of_lunch;

    
        /*var edittab = document.getElementById('editItemMenu');
        
           let a=document.createElement("");
           a.textContent = item.name;
           edittab.appendChild(a);*/
        
    
}




var items = [
    {
       id: 1, name: 'Sandwich', price: 'Rs.99.00', Active: 'Yes', date_of_lunch: '15/03/2017', category: 'Main Course', free_delivery: 'Yes'
    },
    {
       id: 2,  name: 'Burger', price: 'Rs.129', Active: 'Yes', date_of_lunch: '23/12/2017', category: 'Main Course', free_delivery: 'No'
    },
    {
       id: 3, name: 'Pizza', price: 'Rs.149.00', Active: 'Yes', date_of_lunch: '21/08/2017', category: 'Main Course', free_delivery: 'No'
    },
    {
        id: 4, name: 'French Fries', price: 'Rs.57.00', Active: 'No', date_of_lunch: '02/07/2017', category: 'Starters', free_delivery: 'Yes'
    },
    {
        id: 5, name: 'Chocolate Brownie', price: 'Rs.32.00', Active: 'Yes', date_of_lunch: '02/11/2012', category: 'Dessert', free_delivery: 'No'
    }
];
const tabItems = function (items) {
    let menuTab = document.querySelector("#menu");

    items.forEach(function (item) {
        let row = document.createElement("tr");

        let data1 = document.createElement("td");
        data1.textContent = item.name;
        row.appendChild(data1);

        let data2 = document.createElement("td");
        data2.textContent = item.price;
        row.appendChild(data2);

        let data3 = document.createElement("td");
        data3.textContent = item.Active;
        row.appendChild(data3);

        let data4 = document.createElement("td");
        data4.textContent = item.date_of_lunch;
        row.appendChild(data4);

        let data5 = document.createElement("td");
        data5.textContent = item.category;
        row.appendChild(data5);

        let data6 = document.createElement("td");
        data6.textContent = item.free_delivery;
        row.appendChild(data6);

        let data7 = document.createElement("td");
        let editLink = document.createElement('a');
        editLink.setAttribute('id', 'link1');
        editLink.href = "#";

        editLink.onclick = function(){
            toggle();
            editItem(item);
        };
        editLink.textContent = "edit";
        data7.appendChild(editLink);
        row.appendChild(data7);
        menuTab.appendChild(row);

    })
}
tabItems(items);
